import numpy as np
import matplotlib.pyplot as plt

def split_channels_scratch(image_path):
    """
    Splits and displays RGB channels by manually manipulating matrix indices.
    """
    # 1. Read the image as an RGB numpy array
    img_rgb = plt.imread(image_path)
    
    # Verify image format
    if len(img_rgb.shape) < 3 or img_rgb.shape[2] < 3:
        print("Error: Image does not have 3 channels.")
        return
        
    # 2. Create independent copies of the original image matrix for each color
    img_red = np.copy(img_rgb)
    img_green = np.copy(img_rgb)
    img_blue = np.copy(img_rgb)
    
    # 3. Manually zero-pad the non-target channels
    # Red image: set Green (index 1) and Blue (index 2) to 0
    img_red[:, :, 1] = 0
    img_red[:, :, 2] = 0
    
    # Green image: set Red (index 0) and Blue (index 2) to 0
    img_green[:, :, 0] = 0
    img_green[:, :, 2] = 0
    
    # Blue image: set Red (index 0) and Green (index 1) to 0
    img_blue[:, :, 0] = 0
    img_blue[:, :, 1] = 0
    
    # 4. Display the results
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_red)
    plt.title('Red Channel')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(img_green)
    plt.title('Green Channel')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(img_blue)
    plt.title('Blue Channel')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# split_channels_scratch("input.jpg")