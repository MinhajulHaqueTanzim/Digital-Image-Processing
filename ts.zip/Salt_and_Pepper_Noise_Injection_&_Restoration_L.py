import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.util import random_noise

def sp_noise_and_restore_library(image_path, noise_amount=0.05, kernel_size=3):
    """
    Injects salt-and-pepper noise and restores it using library functions.
    noise_amount: Proportion of image pixels to replace with noise (e.g., 0.05 = 5%)
    """
    # 1. Read the image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Inject Salt-and-Pepper noise using scikit-image
    # Note: random_noise converts the image to float in [0.0, 1.0] range
    noisy_img_float = random_noise(img_gray, mode='s&p', amount=noise_amount)
    
    # Scale back to 8-bit integer [0, 255] for OpenCV processing
    noisy_img = np.array(255 * noisy_img_float, dtype=np.uint8)
    
    # 3. Restore the image using OpenCV's Median Filter
    # Kernel size must be odd
    if kernel_size % 2 == 0:
        kernel_size += 1
    restored_img = cv2.medianBlur(noisy_img, kernel_size)
    
    # 4. Display the progression
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(noisy_img, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Noisy Image ({noise_amount*100}% S&P)')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(restored_img, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Restored (Median {kernel_size}x{kernel_size})')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# sp_noise_and_restore_library("input.jpg", noise_amount=0.05, kernel_size=3)