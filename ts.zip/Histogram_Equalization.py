import numpy as np
import matplotlib.pyplot as plt

def hist_equalization_scratch(image_path):
    """
    Applies histogram equalization mathematically from scratch.
    """
    # 1. Read the image and ensure it's a 2D grayscale uint8 array
    img = plt.imread(image_path)
    
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # 2. Calculate the histogram (frequency of each pixel intensity)
    histogram = np.zeros(256, dtype=int)
    for pixel_intensity in range(256):
        histogram[pixel_intensity] = np.sum(img_gray == pixel_intensity)
        
    # 3. Calculate the Cumulative Distribution Function (CDF)
    cdf = np.zeros(256, dtype=float)
    cdf[0] = histogram[0]
    for i in range(1, 256):
        cdf[i] = cdf[i - 1] + histogram[i]
        
    # 4. Normalize the CDF to map into the [0, 255] range
    # Formula: h(v) = round( (CDF(v) - CDF_min) / (Total_Pixels - CDF_min) * 255 )
    cdf_min = cdf[cdf > 0].min() # Minimum non-zero value of the CDF
    total_pixels = img_gray.shape[0] * img_gray.shape[1]
    
    cdf_normalized = np.round(((cdf - cdf_min) / (total_pixels - cdf_min)) * 255)
    cdf_normalized = cdf_normalized.astype(np.uint8)
    
    # 5. Map the original image intensities to the new equalized intensities
    # By using the image matrix as an index, NumPy maps every pixel simultaneously
    img_eq = cdf_normalized[img_gray]
    
    # 6. Plot the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Grayscale Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_eq, cmap='gray', vmin=0, vmax=255)
    plt.title('Equalized Image (From Scratch)')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()
    
    return img_eq

# Example usage:
# hist_equalization_scratch("input.jpg")