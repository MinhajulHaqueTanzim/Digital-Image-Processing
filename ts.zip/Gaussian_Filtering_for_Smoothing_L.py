import cv2
import matplotlib.pyplot as plt

def gaussian_filter_library(image_path, kernel_size=(5, 5), sigma=1.0):
    """
    Applies Gaussian smoothing using OpenCV's built-in GaussianBlur function.
    """
    # 1. Read the image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Apply the built-in Gaussian Blur filter
    # kernel_size determines the neighborhood area (must be odd numbers)
    # sigma determines the standard deviation (how spread out the bell curve is)
    img_smoothed = cv2.GaussianBlur(img_gray, kernel_size, sigmaX=sigma)
    
    # 3. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_smoothed, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Gaussian Smoothed (OpenCV)\nKernel: {kernel_size}, Sigma: {sigma}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# gaussian_filter_library("input.jpg", kernel_size=(7, 7), sigma=1.5)