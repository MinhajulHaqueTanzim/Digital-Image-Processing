import numpy as np
import matplotlib.pyplot as plt

def sp_noise_and_restore_scratch(image_path, noise_prob=0.05, kernel_size=3):
    """
    Injects salt-and-pepper noise and restores it mathematically from scratch.
    """
    # 1. Read and format the image as 2D grayscale uint8
    img = plt.imread(image_path)
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # === STEP 1: INJECT NOISE ===
    noisy_img = np.copy(img_gray)
    
    # Generate a matrix of random probabilities of the same shape as the image
    rand_matrix = np.random.rand(*img_gray.shape)
    
    # Apply Pepper (0): If the random value is in the lower half of the probability
    noisy_img[rand_matrix < (noise_prob / 2)] = 0
    
    # Apply Salt (255): If the random value is in the upper half of the probability
    noisy_img[rand_matrix > 1 - (noise_prob / 2)] = 255
    
    
    # === STEP 2: RESTORE IMAGE ===
    if kernel_size % 2 == 0:
        kernel_size += 1
        
    padding = kernel_size // 2
    padded_img = np.pad(noisy_img, ((padding, padding), (padding, padding)), mode='edge')
    restored_img = np.zeros_like(noisy_img)
    median_index = (kernel_size * kernel_size) // 2
    
    # Manual sliding window for the median filter
    for i in range(noisy_img.shape[0]):
        for j in range(noisy_img.shape[1]):
            # Extract 2D patch and flatten to 1D
            patch = padded_img[i:i+kernel_size, j:j+kernel_size].flatten()
            
            # Sort the patch and select the middle value
            patch_sorted = np.sort(patch)
            restored_img[i, j] = patch_sorted[median_index]
            
            
    # === STEP 3: DISPLAY ===
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(noisy_img, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Noisy Image ({noise_prob*100}% S&P)')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(restored_img, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Restored (Scratch Median {kernel_size}x{kernel_size})')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# sp_noise_and_restore_scratch("input.jpg", noise_prob=0.05, kernel_size=3)