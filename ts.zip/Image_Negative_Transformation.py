import numpy as np
import matplotlib.pyplot as plt

def image_negative_scratch(image_path, output_path="negative_scratch.jpg"):
    """
    Applies negative transformation to a grayscale image mathematically from scratch.
    """
    # 1. Read the image
    img = plt.imread(image_path)
    
    # Ensure it's a 2D grayscale array
    # If the image loaded as RGB (3 channels), take the average across channels to make it grayscale
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    # Normalize image to 0-255 if matplotlib read it as 0.0-1.0 float values
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # 2. Apply the negative transformation formula: s = 255 - r
    # NumPy broadcasts the scalar 255 to subtract every individual element in the matrix
    negative_matrix = 255 - img_gray
    
    # 3. Ensure data type is uint8 
    negative_matrix = negative_matrix.astype(np.uint8)
    
    # 4. Save the result
    plt.imsave(output_path, negative_matrix, cmap='gray', vmin=0, vmax=255)
    print(f"Manual negative transformation successful. Saved to {output_path}")
    
    return negative_matrix

# Example usage:
# image_negative_scratch("input.jpg")