import cv2
import numpy as np
import matplotlib.pyplot as plt

def split_channels_library(image_path):
    """
    Splits and displays RGB channels using OpenCV.
    """
    # 1. Read the image (OpenCV loads as BGR by default)
    img_bgr = cv2.imread(image_path)
    if img_bgr is None:
        print("Error: Could not load image.")
        return
        
    # 2. Split the channels natively using OpenCV
    b, g, r = cv2.split(img_bgr)
    
    # 3. Create a zero matrix of the same dimensions as one of the channels
    zeros = np.zeros_like(b)
    
    # 4. Merge the target channel with zeros for the non-target channels
    # Note: cv2.merge expects the order to match the BGR format
    img_red_bgr = cv2.merge([zeros, zeros, r])
    img_green_bgr = cv2.merge([zeros, g, zeros])
    img_blue_bgr = cv2.merge([b, zeros, zeros])
    
    # 5. Display the results using Matplotlib (requires converting BGR back to RGB for correct display)
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(cv2.cvtColor(img_red_bgr, cv2.COLOR_BGR2RGB))
    plt.title('Red Channel')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(cv2.cvtColor(img_green_bgr, cv2.COLOR_BGR2RGB))
    plt.title('Green Channel')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(cv2.cvtColor(img_blue_bgr, cv2.COLOR_BGR2RGB))
    plt.title('Blue Channel')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# split_channels_library("input.jpg")