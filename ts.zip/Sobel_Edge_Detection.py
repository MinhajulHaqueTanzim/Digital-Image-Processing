import numpy as np
import matplotlib.pyplot as plt

def apply_3x3_convolution(image, kernel):
    """
    Helper function to manually convolve a 3x3 kernel over a 2D image matrix.
    """
    padding = 1 # A 3x3 kernel requires 1 pixel of padding
    padded_image = np.pad(image, ((padding, padding), (padding, padding)), mode='edge')
    output_image = np.zeros_like(image, dtype=np.float64)
    
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            patch = padded_image[i:i+3, j:j+3]
            # Element-wise multiplication of the patch and kernel, then sum
            output_image[i, j] = np.sum(patch * kernel)
            
    return output_image

def sobel_edge_detection_scratch(image_path):
    """
    Applies Sobel Edge Detection mathematically from scratch.
    """
    # 1. Read and format the image as 2D grayscale uint8
    img = plt.imread(image_path)
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # Convert image to float64 to prevent overflow during derivative calculation
    img_float = img_gray.astype(np.float64)
    
    # 2. Define the Sobel Operators mathematically
    # Gx detects changes along the X-axis (highlights vertical edges)
    sobel_x = np.array([[-1,  0,  1],
                        [-2,  0,  2],
                        [-1,  0,  1]])
                        
    # Gy detects changes along the Y-axis (highlights horizontal edges)
    sobel_y = np.array([[-1, -2, -1],
                        [ 0,  0,  0],
                        [ 1,  2,  1]])
                        
    # 3. Apply the operators to the image (2D Convolution)
    grad_x = apply_3x3_convolution(img_float, sobel_x)
    grad_y = apply_3x3_convolution(img_float, sobel_y)
    
    # 4. Calculate the overall gradient magnitude: G = sqrt(Gx^2 + Gy^2)
    magnitude = np.sqrt(np.square(grad_x) + np.square(grad_y))
    
    # 5. Normalize the magnitude to fit into standard 8-bit [0, 255] range
    magnitude_normalized = (magnitude / np.max(magnitude)) * 255.0
    sobel_edges = magnitude_normalized.astype(np.uint8)
    
    # 6. Display the results
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    # Absolute values used for visual plotting only
    plt.imshow(np.abs(grad_x), cmap='gray')
    plt.title('Sobel X (Manual)')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(sobel_edges, cmap='gray')
    plt.title('Sobel Magnitude (Manual)')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# sobel_edge_detection_scratch("input.jpg")