import numpy as np
import matplotlib.pyplot as plt

def ihpf_scratch(image_path, D0=50):
    """
    Applies an Ideal High-Pass Filter by mathematically calculating frequency distances.
    D0: Cutoff frequency
    """
    # 1. Read image and format as 2D grayscale
    img = plt.imread(image_path)
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    # 2. Compute 2D Fast Fourier Transform and shift zero-frequency to the center
    F = np.fft.fft2(img_gray)
    F_shifted = np.fft.fftshift(F)
    
    # 3. Create the mathematical Ideal High-Pass Filter (IHPF) mask H(u,v)
    M, N = img_gray.shape
    X, Y = np.meshgrid(np.arange(N), np.arange(M))
    
    center_u, center_v = M // 2, N // 2
    
    # Calculate Euclidean distance D(u,v) from the center
    D = np.sqrt((Y - center_u)**2 + (X - center_v)**2)
    
    # Construct the piecewise filter matrix: 
    # Start with all 1s (high frequencies allowed)
    H = np.ones((M, N), dtype=float)
    # Set inside the radius to 0 (low frequencies blocked)
    H[D <= D0] = 0.0
    
    # 4. Apply the filter mask to the shifted frequency matrix
    G_shifted = F_shifted * H
    
    # 5. Compute Inverse Fourier Transform
    G = np.fft.ifftshift(G_shifted)
    img_filtered_complex = np.fft.ifft2(G)
    
    # Extract the absolute magnitude
    img_filtered = np.abs(img_filtered_complex)
    
    # High-pass images have a lot of near-zero values (dark) and intense spikes (edges).
    # Normalizing is usually required to visualize the edges properly.
    img_filtered = (img_filtered / np.max(img_filtered)) * 255.0
    img_filtered = np.clip(img_filtered, 0, 255).astype(np.uint8)
    
    # 6. Display the results
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(H, cmap='gray')
    plt.title(f'IHPF Mask (Cutoff D0 = {D0})')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(img_filtered, cmap='gray')
    plt.title('Filtered Edges')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# ihpf_scratch("input.jpg", D0=50)