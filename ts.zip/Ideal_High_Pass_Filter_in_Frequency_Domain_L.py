import cv2
import numpy as np
import matplotlib.pyplot as plt

def ihpf_library(image_path, D0=50):
    """
    Applies an Ideal High-Pass Filter using OpenCV's DFT and drawing tools.
    D0: Cutoff frequency (radius of the blocked low-frequency circle)
    """
    # 1. Read image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Compute the Discrete Fourier Transform (DFT)
    # Output is complex (Real, Imaginary), so it has 2 channels
    dft = cv2.dft(np.float32(img_gray), flags=cv2.DFT_COMPLEX_OUTPUT)
    
    # Shift zero-frequency components to the center
    dft_shift = np.fft.fftshift(dft)
    
    # 3. Create the Ideal High-Pass Filter mask
    rows, cols = img_gray.shape
    center_row, center_col = rows // 2, cols // 2
    
    # Initialize mask of ONES (allows everything by default)
    mask = np.ones((rows, cols, 2), np.uint8)
    
    # Draw a solid filled ZERO circle at the center with radius D0 to block low frequencies
    cv2.circle(mask, (center_col, center_row), D0, (0, 0), -1)
    
    # 4. Apply the mask
    fshift_filtered = dft_shift * mask
    
    # 5. Compute Inverse DFT
    f_ishift = np.fft.ifftshift(fshift_filtered)
    img_back = cv2.idft(f_ishift)
    
    # Calculate magnitude
    img_filtered = cv2.magnitude(img_back[:, :, 0], img_back[:, :, 1])
    
    # Normalize to 0-255 for proper display of the edges
    cv2.normalize(img_filtered, img_filtered, 0, 255, cv2.NORM_MINMAX)
    img_filtered = np.uint8(img_filtered)
    
    # 6. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_filtered, cmap='gray')
    plt.title(f'IHPF Filtered (OpenCV) - D0: {D0}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# ihpf_library("input.jpg", D0=50)