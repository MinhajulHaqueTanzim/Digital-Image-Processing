import cv2
import matplotlib.pyplot as plt

def median_filter_library(image_path, kernel_size=5):
    """
    Applies median filtering using OpenCV's built-in medianBlur function.
    """
    # 1. Read the image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # Kernel size must be an odd integer greater than 1 (e.g., 3, 5, 7)
    if kernel_size % 2 == 0:
        kernel_size += 1 
        
    # 2. Apply built-in median filter
    img_filtered = cv2.medianBlur(img_gray, kernel_size)
    
    # 3. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Image (Noisy)')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_filtered, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Median Filtered (OpenCV)\nKernel: {kernel_size}x{kernel_size}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# median_filter_library("noisy_input.jpg", kernel_size=5)