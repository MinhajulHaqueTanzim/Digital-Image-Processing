import cv2
import numpy as np
import matplotlib.pyplot as plt

def ilpf_library(image_path, D0=50):
    """
    Applies an Ideal Low-Pass Filter using OpenCV's DFT and geometric drawing tools.
    D0: Cutoff frequency (radius of the low-pass circle)
    """
    # 1. Read image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Compute the Discrete Fourier Transform (DFT)
    # OpenCV's DFT requires float32 arrays and outputs a 2-channel array (Real, Imaginary)
    dft = cv2.dft(np.float32(img_gray), flags=cv2.DFT_COMPLEX_OUTPUT)
    
    # Shift the zero-frequency component (DC) to the center of the spectrum
    dft_shift = np.fft.fftshift(dft)
    
    # 3. Create the Ideal Low-Pass Filter mask using OpenCV's drawing tool
    rows, cols = img_gray.shape
    center_row, center_col = rows // 2, cols // 2
    
    # Initialize mask of zeros (2 channels for Real/Imaginary)
    mask = np.zeros((rows, cols, 2), np.uint8)
    
    # Draw a solid filled circle (thickness=-1) at the center with radius D0
    # The circle area gets 1s (allows low frequencies), everything else remains 0 (blocks high frequencies)
    cv2.circle(mask, (center_col, center_row), D0, (1, 1), -1)
    
    # 4. Apply the mask in the frequency domain
    fshift_filtered = dft_shift * mask
    
    # 5. Compute Inverse DFT to return to spatial domain
    # Shift the zero-frequency back to the top-left corner
    f_ishift = np.fft.ifftshift(fshift_filtered)
    img_back = cv2.idft(f_ishift)
    
    # Calculate magnitude from the Real and Imaginary components
    img_filtered = cv2.magnitude(img_back[:, :, 0], img_back[:, :, 1])
    
    # Normalize to 0-255 for display
    cv2.normalize(img_filtered, img_filtered, 0, 255, cv2.NORM_MINMAX)
    img_filtered = np.uint8(img_filtered)
    
    # 6. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_filtered, cmap='gray')
    plt.title(f'ILPF Filtered (OpenCV) - D0: {D0}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# ilpf_library("input.jpg", D0=50)