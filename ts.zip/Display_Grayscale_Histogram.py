import numpy as np
import matplotlib.pyplot as plt

def display_histogram_scratch(image_path):
    """
    Calculates and plots a grayscale histogram by manually counting pixel intensities.
    """
    # 1. Read the image and ensure it is grayscale 2D array
    img = plt.imread(image_path)
    
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    # Normalize to 0-255 integer range if needed
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # 2. Initialize an array of 256 zeros to act as our histogram bins
    histogram = np.zeros(256, dtype=int)
    
    # 3. Manually calculate the histogram
    # We iterate through all possible intensities (0-255) and count matches in the image matrix
    for pixel_intensity in range(256):
        # np.sum(img_gray == pixel_intensity) counts how many pixels have this exact value
        histogram[pixel_intensity] = np.sum(img_gray == pixel_intensity)
        
    # 4. Plot the original image and the manually calculated histogram
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Grayscale Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    # Using a bar chart or fill_between is standard for from-scratch histograms
    plt.bar(range(256), histogram, color='black', width=1)
    plt.title('Grayscale Histogram (From Scratch)')
    plt.xlabel('Pixel Intensity')
    plt.ylabel('Frequency (Pixel Count)')
    plt.xlim([0, 256])
    plt.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.show()

# Example usage:
# display_histogram_scratch("input.jpg")