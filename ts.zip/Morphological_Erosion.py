import numpy as np
import matplotlib.pyplot as plt

def erosion_scratch(image_path, kernel_size=5):
    """
    Applies morphological erosion manually using a sliding 2D window.
    """
    # 1. Read and format the image as 2D grayscale uint8
    img = plt.imread(image_path)
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # 2. Binarize the image (Threshold at 127)
    # White (255) is the foreground object, Black (0) is the background
    img_binary = np.where(img_gray > 127, 255, 0).astype(np.uint8)
    
    # 3. Setup padding and output matrix
    padding = kernel_size // 2
    
    # We pad with 255 (foreground). If we padded with 0s, the image borders 
    # would artificially erode inwards even if the object touched the edge.
    padded_img = np.pad(img_binary, ((padding, padding), (padding, padding)), 
                        mode='constant', constant_values=255)
                        
    img_eroded = np.zeros_like(img_binary)
    
    # 4. Slide the square kernel over the image
    for i in range(img_binary.shape[0]):
        for j in range(img_binary.shape[1]):
            # Extract the neighborhood patch under the structuring element
            patch = padded_img[i:i+kernel_size, j:j+kernel_size]
            
            # The morphological erosion rule for binary images:
            # If all pixels under the kernel are 255, keep 255. Otherwise, 0.
            # This is mathematically equivalent to taking the minimum of the patch.
            img_eroded[i, j] = np.min(patch)
            
    # 5. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_binary, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Binary Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_eroded, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Eroded Image (From Scratch)\nKernel: {kernel_size}x{kernel_size}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# erosion_scratch("input.jpg", kernel_size=5)