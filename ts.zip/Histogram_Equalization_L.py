import cv2
import matplotlib.pyplot as plt

def hist_equalization_library(image_path):
    """
    Applies histogram equalization using OpenCV's built-in function.
    """
    # 1. Read the image in grayscale mode
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Apply built-in histogram equalization
    img_eq = cv2.equalizeHist(img_gray)
    
    # 3. Plot original vs. equalized image
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Grayscale Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_eq, cmap='gray', vmin=0, vmax=255)
    plt.title('Equalized Image (OpenCV)')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()
    
    return img_eq

# Example usage:
# hist_equalization_library("input.jpg")