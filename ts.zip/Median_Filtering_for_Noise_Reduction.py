import numpy as np
import matplotlib.pyplot as plt

def median_filter_scratch(image_path, kernel_size=5):
    """
    Applies median filtering manually using a sliding 2D window and array sorting.
    """
    # 1. Read the image and enforce grayscale uint8 format
    img = plt.imread(image_path)
    
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # Kernel size must be odd
    if kernel_size % 2 == 0:
        kernel_size += 1
        
    padding = kernel_size // 2
    
    # 2. Pad the image matrix to handle pixels along the edges
    # Using 'edge' padding (repeating edge pixels) prevents dark borders common in zero-padding
    padded_image = np.pad(img_gray, ((padding, padding), (padding, padding)), mode='edge')
    
    # 3. Create an empty matrix for the output
    img_filtered = np.zeros_like(img_gray)
    
    # Calculate the index of the median value in a flattened array
    median_index = (kernel_size * kernel_size) // 2
    
    # 4. Slide the window over the image
    for i in range(img_gray.shape[0]):
        for j in range(img_gray.shape[1]):
            # Extract the neighborhood patch
            patch = padded_image[i:i+kernel_size, j:j+kernel_size]
            
            # Flatten the 2D patch into a 1D array
            patch_1d = patch.flatten()
            
            # Sort the array manually (using NumPy's base sort algorithm)
            patch_sorted = np.sort(patch_1d)
            
            # Extract the median value and assign it to the target pixel
            img_filtered[i, j] = patch_sorted[median_index]
            
    # 5. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Image (Noisy)')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_filtered, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Median Filtered (From Scratch)\nKernel: {kernel_size}x{kernel_size}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# median_filter_scratch("noisy_input.jpg", kernel_size=5)