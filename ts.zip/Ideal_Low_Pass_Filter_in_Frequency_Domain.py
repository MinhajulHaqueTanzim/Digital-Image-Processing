import numpy as np
import matplotlib.pyplot as plt

def ilpf_scratch(image_path, D0=50):
    """
    Applies an Ideal Low-Pass Filter by mathematically calculating frequency distances.
    D0: Cutoff frequency
    """
    # 1. Read image and format as 2D grayscale array
    img = plt.imread(image_path)
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    # 2. Compute 2D Fourier Transform and shift zero-frequency to center
    # This transforms the image from spatial domain (pixels) to frequency domain (waves)
    F = np.fft.fft2(img_gray)
    F_shifted = np.fft.fftshift(F)
    
    # 3. Create the mathematical Ideal Low-Pass Filter (ILPF) mask H(u,v)
    M, N = img_gray.shape
    
    # Create a coordinate grid mapping the image dimensions
    X, Y = np.meshgrid(np.arange(N), np.arange(M))
    
    # Define the center coordinates of the frequency matrix
    center_u, center_v = M // 2, N // 2
    
    # Calculate Euclidean distance D(u,v) for every frequency component to the center
    # Formula: D(u, v) = sqrt((u - M/2)^2 + (v - N/2)^2)
    D = np.sqrt((Y - center_u)**2 + (X - center_v)**2)
    
    # Construct the piecewise filter matrix: 1 if distance <= D0, 0 otherwise
    H = np.zeros((M, N), dtype=float)
    H[D <= D0] = 1.0
    
    # 4. Multiply the shifted frequency matrix by the filter mask
    # High frequencies (edges, noise) are multiplied by 0 and destroyed
    G_shifted = F_shifted * H
    
    # 5. Compute Inverse Fourier Transform
    G = np.fft.ifftshift(G_shifted)
    img_filtered_complex = np.fft.ifft2(G)
    
    # Extract the absolute magnitude (real spatial image)
    img_filtered = np.abs(img_filtered_complex)
    
    # Scale back to valid 8-bit image range
    img_filtered = np.clip(img_filtered, 0, 255).astype(np.uint8)
    
    # 6. Display the results
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(H, cmap='gray')
    plt.title(f'ILPF Mask (Cutoff D0 = {D0})')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(img_filtered, cmap='gray')
    plt.title('Filtered Image (Notice the "ringing" artifact)')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# ilpf_scratch("input.jpg", D0=50)