import cv2

def rgb_to_gray_library(image_path, output_path="gray_lib.jpg"):
    """
    Converts an RGB image to grayscale using OpenCV's built-in function.
    """
    # 1. Read the image. Note: OpenCV reads images in BGR format by default.
    img_bgr = cv2.imread(image_path)
    
    if img_bgr is None:
        print("Error: Could not load image.")
        return
        
    # 2. Convert BGR to Grayscale using the built-in library method
    gray_img = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    
    # 3. Save the result
    cv2.imwrite(output_path, gray_img)
    print(f"Library conversion successful. Saved to {output_path}")
    
    return gray_img

# Example usage:
# rgb_to_gray_library("input.jpg")