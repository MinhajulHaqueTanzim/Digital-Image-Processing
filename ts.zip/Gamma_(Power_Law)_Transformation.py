import numpy as np
import matplotlib.pyplot as plt

def gamma_transform_scratch(image_path, gammas=[0.4, 1.0, 2.2]):
    """
    Applies Power-Law transformation manually using array mathematics.
    """
    # 1. Read the image
    img = plt.imread(image_path)
    
    # Ensure it's a 2D grayscale array for consistency
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    # Standardize to 0-255 if matplotlib read it as floats
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        if img_gray.max() <= 1.0:
            img_gray = (img_gray * 255).astype(np.uint8)
            
    plt.figure(figsize=(15, 5))
    
    # 2. Normalize the matrix to [0, 1] so powers scale correctly
    img_normalized = img_gray / 255.0
    
    # 3. Iterate through the selection of gamma parameters
    for i, gamma in enumerate(gammas):
        # Apply formula: s = c * r^gamma (where c = 1)
        gamma_matrix = np.power(img_normalized, gamma)
        
        # Scale back to [0, 255] range
        gamma_matrix_scaled = gamma_matrix * 255.0
        
        # Convert to 8-bit integer, ensuring values don't overflow
        final_img = np.clip(gamma_matrix_scaled, 0, 255).astype(np.uint8)
        
        # Display the result
        plt.subplot(1, len(gammas), i + 1)
        plt.imshow(final_img, cmap='gray', vmin=0, vmax=255)
        plt.title(f'Gamma = {gamma}')
        plt.axis('off')
        
    plt.tight_layout()
    plt.show()

# Example usage:
# gamma_transform_scratch("input.jpg", gammas=[0.5, 1.0, 2.5])