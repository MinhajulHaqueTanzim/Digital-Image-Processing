import numpy as np
import matplotlib.pyplot as plt

def generate_gaussian_kernel(size, sigma):
    """
    Mathematically generates a 2D Gaussian kernel matrix.
    """
    kernel = np.zeros((size, size))
    center = size // 2
    
    # Formula for 2D Gaussian: G(x,y) = (1 / 2*pi*sigma^2) * e^(-(x^2 + y^2) / 2*sigma^2)
    for i in range(size):
        for j in range(size):
            # Calculate (x, y) distance from the center pixel
            x = i - center
            y = j - center
            
            # Apply Gaussian function
            exponent = -(x**2 + y**2) / (2 * sigma**2)
            kernel[i, j] = (1 / (2 * np.pi * sigma**2)) * np.exp(exponent)
            
    # Normalize the kernel so the weights sum to 1 (preserves image brightness)
    return kernel / np.sum(kernel)

def apply_2d_convolution(image, kernel):
    """
    Manually convolves a kernel over a 2D image matrix.
    """
    kernel_size = kernel.shape[0]
    padding = kernel_size // 2
    
    # Create a padded image (filling borders with 0s) to handle the edges
    padded_image = np.pad(image, ((padding, padding), (padding, padding)), mode='constant', constant_values=0)
    
    # Create an empty matrix for the output
    output_image = np.zeros_like(image, dtype=np.float64)
    
    # Slide the kernel over every pixel in the original image dimensions
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            # Extract the neighborhood patch around the current pixel
            patch = padded_image[i:i+kernel_size, j:j+kernel_size]
            
            # Element-wise multiplication of the patch and kernel, then sum
            output_image[i, j] = np.sum(patch * kernel)
            
    return output_image

def gaussian_filter_scratch(image_path, kernel_size=5, sigma=1.0):
    """
    Applies Gaussian smoothing mathematically from scratch.
    """
    # 1. Read the image and enforce grayscale uint8 format
    img = plt.imread(image_path)
    
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # 2. Generate the Gaussian kernel mathematically
    if kernel_size % 2 == 0:
        kernel_size += 1 # Kernel size must be an odd number to have a center
        
    kernel = generate_gaussian_kernel(kernel_size, sigma)
    
    # 3. Apply manual 2D convolution
    smoothed_matrix = apply_2d_convolution(img_gray, kernel)
    
    # 4. Clip to valid pixel range and convert to integers
    img_smoothed = np.clip(smoothed_matrix, 0, 255).astype(np.uint8)
    
    # 5. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_smoothed, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Gaussian Smoothed (From Scratch)\nKernel: {kernel_size}x{kernel_size}, Sigma: {sigma}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# gaussian_filter_scratch("input.jpg", kernel_size=7, sigma=1.5)