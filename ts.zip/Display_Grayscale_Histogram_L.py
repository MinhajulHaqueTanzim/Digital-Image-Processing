import cv2
import matplotlib.pyplot as plt

def display_histogram_library(image_path):
    """
    Calculates and plots a grayscale histogram using OpenCV's calcHist function.
    """
    # 1. Read the image in grayscale mode
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Calculate the histogram using OpenCV
    # Arguments: images, channels, mask, histSize (bins), ranges
    hist = cv2.calcHist([img_gray], [0], None, [256], [0, 256])
    
    # 3. Plot the original image and its histogram
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_gray, cmap='gray', vmin=0, vmax=255)
    plt.title('Grayscale Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.plot(hist, color='black')
    plt.title('Grayscale Histogram (OpenCV)')
    plt.xlabel('Pixel Intensity')
    plt.ylabel('Frequency (Pixel Count)')
    plt.xlim([0, 256])
    plt.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.show()

# Example usage:
# display_histogram_library("input.jpg")