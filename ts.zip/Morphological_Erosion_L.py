import cv2
import numpy as np
import matplotlib.pyplot as plt

def erosion_library(image_path, kernel_size=5):
    """
    Applies morphological erosion using OpenCV.
    kernel_size: Defines the size of the square structuring element.
    """
    # 1. Read the image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Convert to binary image (Foreground = 255, Background = 0)
    # Uses a simple threshold of 127
    _, img_binary = cv2.threshold(img_gray, 127, 255, cv2.THRESH_BINARY)
    
    # 3. Create a square structuring element (kernel)
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    
    # 4. Apply OpenCV's built-in erosion
    img_eroded = cv2.erode(img_binary, kernel, iterations=1)
    
    # 5. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_binary, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Binary Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_eroded, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Eroded Image (OpenCV)\nKernel: {kernel_size}x{kernel_size}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# erosion_library("input.jpg", kernel_size=5)