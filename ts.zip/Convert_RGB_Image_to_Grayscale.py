import numpy as np
import matplotlib.pyplot as plt

def rgb_to_gray_scratch(image_path, output_path="gray_scratch.jpg"):
    """
    Converts an RGB image to grayscale manually using standard luminance weighting.
    """
    # 1. Read the image as an RGB numpy array
    img_rgb = plt.imread(image_path)
    
    # Normalize image to 0-255 if it was read as 0.0-1.0 float values (png vs jpg behavior)
    if img_rgb.dtype == np.float32 or img_rgb.dtype == np.float64:
        img_rgb = (img_rgb * 255).astype(np.uint8)
        
    # Check if image actually has 3 channels (RGB)
    if len(img_rgb.shape) < 3 or img_rgb.shape[2] < 3:
        print("Error: Image is not in RGB format.")
        return img_rgb
        
    # 2. Extract the individual color channels (R, G, B)
    R = img_rgb[:, :, 0]
    G = img_rgb[:, :, 1]
    B = img_rgb[:, :, 2]
    
    # 3. Apply standard luminance formula: Y = 0.2989R + 0.5870G + 0.1140B
    # Using matrix operations to apply the calculation to every pixel simultaneously 
    gray_matrix = (0.2989 * R) + (0.5870 * G) + (0.1140 * B)
    
    # 4. Ensure values stay within valid pixel range [0, 255] and convert to 8-bit integers
    gray_img = np.clip(gray_matrix, 0, 255).astype(np.uint8)
    
    # 5. Save the result
    plt.imsave(output_path, gray_img, cmap='gray')
    print(f"Manual conversion successful. Saved to {output_path}")
    
    return gray_img

# Example usage:
# rgb_to_gray_scratch("input.jpg")