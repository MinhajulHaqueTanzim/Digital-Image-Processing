import cv2

def image_negative_library(image_path, output_path="negative_lib.jpg"):
    """
    Applies negative transformation to a grayscale image using OpenCV's bitwise_not.
    """
    # 1. Read the image directly in grayscale mode
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Apply built-in image inversion (equivalent to 255 - pixel_value)
    negative_img = cv2.bitwise_not(img_gray)
    
    # 3. Save the result
    cv2.imwrite(output_path, negative_img)
    print(f"Library negative transformation successful. Saved to {output_path}")
    
    return negative_img

# Example usage:
# image_negative_library("input.jpg")