import cv2
import matplotlib.pyplot as plt
from skimage import exposure

def gamma_transform_library(image_path, gammas=[0.4, 1.0, 2.2]):
    """
    Applies Power-Law transformation using scikit-image's built-in adjust_gamma function.
    """
    # 1. Read the image in grayscale using OpenCV
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    plt.figure(figsize=(15, 5))
    
    # 2. Iterate through the selection of gamma parameters
    for i, gamma in enumerate(gammas):
        # Apply the built-in gamma adjustment function
        # It automatically handles normalizing to [0,1] and scaling back out
        transformed_img = exposure.adjust_gamma(img_gray, gamma=gamma)
        
        # Display the result
        plt.subplot(1, len(gammas), i + 1)
        plt.imshow(transformed_img, cmap='gray', vmin=0, vmax=255)
        plt.title(f'Gamma = {gamma}')
        plt.axis('off')
        
    plt.tight_layout()
    plt.show()

# Example usage:
# gamma_transform_library("input.jpg", gammas=[0.5, 1.0, 2.5])