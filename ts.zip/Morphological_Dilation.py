import numpy as np
import matplotlib.pyplot as plt

def dilation_scratch(image_path, kernel_size=5):
    """
    Applies morphological dilation manually using a sliding 2D window.
    """
    # 1. Read and format the image as 2D grayscale uint8
    img = plt.imread(image_path)
    if len(img.shape) == 3:
        img_gray = np.mean(img[:, :, :3], axis=2)
    else:
        img_gray = img
        
    if img_gray.dtype == np.float32 or img_gray.dtype == np.float64:
        img_gray = (img_gray * 255).astype(np.uint8)
    else:
        img_gray = img_gray.astype(np.uint8)
        
    # 2. Binarize the image (Threshold at 127)
    img_binary = np.where(img_gray > 127, 255, 0).astype(np.uint8)
    
    # 3. Setup padding and output matrix
    padding = kernel_size // 2
    
    # We pad with 0 (background). If we padded with 255s, the image borders 
    # would artificially dilate inwards across the entire edge.
    padded_img = np.pad(img_binary, ((padding, padding), (padding, padding)), 
                        mode='constant', constant_values=0)
                        
    img_dilated = np.zeros_like(img_binary)
    
    # 4. Slide the square kernel over the image
    for i in range(img_binary.shape[0]):
        for j in range(img_binary.shape[1]):
            # Extract the neighborhood patch under the structuring element
            patch = padded_img[i:i+kernel_size, j:j+kernel_size]
            
            # The morphological dilation rule for binary images:
            # If any pixel under the kernel is 255, it becomes 255. Otherwise, 0.
            # This is mathematically equivalent to taking the maximum of the patch.
            img_dilated[i, j] = np.max(patch)
            
    # 5. Display the results
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_binary, cmap='gray', vmin=0, vmax=255)
    plt.title('Original Binary Image')
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_dilated, cmap='gray', vmin=0, vmax=255)
    plt.title(f'Dilated Image (From Scratch)\nKernel: {kernel_size}x{kernel_size}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# dilation_scratch("input.jpg", kernel_size=5)