import cv2
import numpy as np
import matplotlib.pyplot as plt

def sobel_edge_detection_library(image_path):
    """
    Applies Sobel Edge Detection using OpenCV.
    """
    # 1. Read the image in grayscale
    img_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img_gray is None:
        print("Error: Could not load image.")
        return
        
    # 2. Calculate the gradients in the X and Y directions
    # cv2.CV_64F is used so that negative gradient values are not clipped to 0
    grad_x = cv2.Sobel(img_gray, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(img_gray, cv2.CV_64F, 0, 1, ksize=3)
    
    # 3. Calculate the gradient magnitude
    magnitude = cv2.magnitude(grad_x, grad_y)
    
    # 4. Normalize the magnitude back to an 8-bit image [0, 255]
    magnitude = cv2.normalize(magnitude, None, 0, 255, cv2.NORM_MINMAX)
    sobel_edges = np.uint8(magnitude)
    
    # 5. Display the results
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    # Using absolute values just for visualization of the directional gradients
    plt.imshow(np.abs(grad_x), cmap='gray')
    plt.title('Sobel X (Vertical Edges)')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(sobel_edges, cmap='gray')
    plt.title('Sobel Magnitude (Combined)')
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()

# Example usage:
# sobel_edge_detection_library("input.jpg")